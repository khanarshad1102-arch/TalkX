# TalkX 🌍

## Setup

### 1. Install Node.js
https://nodejs.org

### 2. Start server
cd server
npm install
node server.js

### 3. Open client
Open client/index.html in browser

## Deploy
- Backend: Render
- Frontend: Vercel
